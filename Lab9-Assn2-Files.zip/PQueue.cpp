/* 
 * PQueue.cpp
 *
 * Description: Link-based implementation of data collection Priority Queue ADT.
 * 
 * Author: Inspired by Frank M. Carrano and Tim Henry (textbook).
 *
 * Date: June 2016
 *
 */ 

#include "PQueue.h"  // Header file

  
// Default Constructor
PQueue::PQueue() {
   Node* head = NULL;
   elementCount = 0;
} // end of default constructor

// Copy Constructor
PQueue::PQueue(const PQueue& rhsPQueue) {
   head = copyLinkedList(rhsPQueue.head);
   elementCount = rhsPQueue.elementCount;
}  // end copy constructor


// Utility method - Copy a linked list
Node* PQueue::copyLinkedList(const Node* originalHead) {
    Node* copiedHead = NULL;

	if (originalHead != NULL)
	{
		// Build new linked list from given one
		copiedHead = new Node(originalHead->data);
		if ( copiedHead != NULL )
			copiedHead->next = copyLinkedList(originalHead->next);
		else
		   return NULL; 
	}  // end if
   
	return copiedHead;
}  // end copylinked list

// Destructor
PQueue::~PQueue() {
   clear();
}  // end destructor


// Utility method - Destroy the whole linked list - same as dequeueAll()
void PQueue::clear()
{
   while (!isEmpty())
      dequeue();
}  // end clear

// Description: Returns "true" is this Priority Queue is empty, otherwise "false".
// Time Efficiency: O(1)
bool PQueue::isEmpty() const {
   return ( elementCount == 0 && head == NULL );
}  // end isEmpty


// Description: Inserts newElement in sort order.
//              It returns "true" if successful, otherwise "false".
// Precondition: This Priority Queue is sorted.   
// Postcondition: Once newElement is inserted, this Priority Queue remains sorted.  
// Time Efficiency: O(n)         
bool PQueue::enqueue(const Event& newElement) {

   bool ableToEnqueue = false;

   Node* newNode = new Node(newElement);

   if ( newNode != NULL ){  
   
   	   Node* previous = getNodeBefore(newElement);
        
	   if ( isEmpty() || previous == NULL) { // Add at beginning
	      newNode->next = head;
	      head = newNode;
	   }
	   else {  // Add after node before
      	   Node* afterNode = previous->next;
      	   newNode->next = afterNode;
      	   previous->next = newNode;
       } // end if

	   elementCount++;    // Increment count of elements
	   ableToEnqueue = true; 
   }

   return ableToEnqueue;

} // end enqueue

// Utility method - Locates the node that is before the node that should or does
//                  contain the anElement.
Node* PQueue::getNodeBefore(const Event& anElement) const {

   Node* current = this->head;  
   Node* previous = NULL;

   while ( (current != NULL) && (current->data < anElement) ) {
		  previous = current;
		  current = current->next;
	   	   
	} // end while

   return previous;
} // end getNodeBefore

// Description: Removes the element with the "highest" priority.
//              It returns "true" if successful, otherwise "false".
// Precondition: This Priority Queue is not empty.
// Time Efficiency: O(1)
bool PQueue::dequeue() {
   bool ableToDequeue = false;
      
   if ( !isEmpty() ) {
      Node* current = head;

      // Delete the first node in the linked list
      head = head->next;
       
      // Return deleted node to system
      current->next = NULL;
      delete current;
      current = NULL;
      
      elementCount--;  // Decrement count of elements
      ableToDequeue = true;
   }  // end if
   
   return ableToDequeue;
}  // end remove

// Description: Retrieves (but does not remove) the element with the "highest" priority.
// Precondition: This Priority Queue is not empty.
// Postcondition: This Priority Queue is unchanged.
// Exceptions: Throws EmptyDataCollectionException if this Priority Queue is empty.
// Time Efficiency: O(1)
Event PQueue::peek() const throw(EmptyDataCollectionException) {
   
   // Enforce precondition
   if ( !isEmpty() )
   {
      Node* node = head;
      return node->data;
   }
   else
      throw(EmptyDataCollectionException("peek() called with an empty PQueue.")); 

}  // end peek


// Description: Overloading assignment operator
void PQueue::operator=(const PQueue& rhsPQueue) {
   head = copyLinkedList(rhsPQueue.head);
   elementCount = rhsPQueue.elementCount;
} 

// For Testing Purposes - See Labs 3 and 4.
// Description: Prints the content of rhs. 
ostream& operator<<(ostream & os, const PQueue& rhs) {
  	Node* current = rhs.head;
	
	// Traverse the list
	while (current != NULL){
		cout << current -> data; // Print data
		current = current -> next; // Go to next Node
	}
	
	return os;
} // end of operator <<

//  End of implementation file.