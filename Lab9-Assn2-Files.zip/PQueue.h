/* 
 * PQueue.h
 *
 * Description: Link-based implementation of data collection Priority Queue ADT.
 * 
 * Author: Inspired by Frank M. Carrano and Tim Henry (textbook).
 *
 * Date: June 2016
 *
 */   
#pragma once

#include <iostream>
#include "Node.h"
#include "EmptyDataCollectionException.h"

using namespace std;


class PQueue {

private:
   Node* head;     // Pointer to first node in the chain
   int elementCount;     // Current count of list items
   
   // Utility method - Locates the node that is before the node that should or does
   //                  contain the anElement.
   Node* getNodeBefore(const Event& anElement) const;

   // Utility method - Destroy the whole linked list - same as dequeueAll()
   void clear();

   // Utility method - Copy a linked list
   Node* copyLinkedList(const Node* originalHead);

   
public:
   // Default Constructor
   PQueue();
   // Copy Constructor
   PQueue(const PQueue& rhsPQueue);
   // Destructor
   ~PQueue();   
   
   // Description: Returns "true" is this Priority Queue is empty, otherwise "false".
   // Time Efficiency: O(1)
   bool isEmpty() const;
   
   // Description: Inserts newElement in sort order.
   //              It returns "true" if successful, otherwise "false".
   // Precondition: This Priority Queue is sorted.   
   // Postcondition: Once newElement is inserted, this Priority Queue remains sorted.    
   // Time Efficiency: O(n)        
   bool enqueue(const Event& newElement);
      
   // Description: Removes the element with the "highest" priority.
   //              It returns "true" if successful, otherwise "false".
   // Precondition: This Priority Queue is not empty.
   // Time Efficiency: O(1) 
   bool dequeue();
   
   // Description: Retrieves (but does not remove) the element with the "highest" priority.
   // Precondition: This Priority Queue is not empty.
   // Postcondition: This Priority Queue is unchanged.
   // Exceptions: Throws EmptyDataCollectionException if this Priority Queue is empty.
   // Time Efficiency: O(1) 
   Event peek() const throw(EmptyDataCollectionException);  

   // Description: Overloading assignment operator
   void operator=(const PQueue& rhsPQueue);

   // For Testing Purposes - See Labs 3 and 4.
   // Description: Prints the content of "this". 
   friend ostream & operator<<(ostream & os, const PQueue& rhs); 

   
}; // end PQueue