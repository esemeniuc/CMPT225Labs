#include "Fraction.h"
#include <iostream>

using namespace std;

int main (void) {
  // Use this driver program to test cout <<.

}
